This folder contains example programs for deal.II
-------------------------------------------------

They are distributed under the same license as the deal.II library itself,
namely LGPL-2.1+.
