#ifndef dealii__tensor_base_h
#define dealii__tensor_base_h
#warning This file is deprecated. Use <deal.II/base/tensor.h> instead.
#endif

#  include <deal.II/base/tensor.h>
